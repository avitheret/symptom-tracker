
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/push-reminders.mts
import webpush from "web-push";
function isDueNow(reminder, utcOffsetMinutes) {
  if (!reminder.enabled) return false;
  const utcNow = /* @__PURE__ */ new Date();
  const utcTotalMinutes = utcNow.getUTCHours() * 60 + utcNow.getUTCMinutes();
  const localTotalMinutes = (utcTotalMinutes + utcOffsetMinutes + 1440) % 1440;
  const localHH = Math.floor(localTotalMinutes / 60);
  const localMM = localTotalMinutes % 60;
  const localDayOfWeek = new Date(Date.UTC(
    utcNow.getUTCFullYear(),
    utcNow.getUTCMonth(),
    utcNow.getUTCDate(),
    utcNow.getUTCHours(),
    utcNow.getUTCMinutes()
  ).valueOf() + utcOffsetMinutes * 6e4).getUTCDay();
  const localDayOfMonth = new Date(Date.UTC(
    utcNow.getUTCFullYear(),
    utcNow.getUTCMonth(),
    utcNow.getUTCDate(),
    utcNow.getUTCHours(),
    utcNow.getUTCMinutes()
  ).valueOf() + utcOffsetMinutes * 6e4).getUTCDate();
  const [reminderHH, reminderMM] = reminder.time.split(":").map(Number);
  switch (reminder.repeat) {
    case "hourly":
      return localMM === reminderMM;
    case "daily":
      return localHH === reminderHH && localMM === reminderMM;
    case "weekly":
      return localHH === reminderHH && localMM === reminderMM && (reminder.daysOfWeek ?? []).includes(localDayOfWeek);
    case "monthly":
      return localHH === reminderHH && localMM === reminderMM && reminder.dayOfMonth === localDayOfMonth;
    default:
      return false;
  }
}
function sentKey(reminderId, utcNow, repeat) {
  const YYYY = utcNow.getUTCFullYear();
  const MM = String(utcNow.getUTCMonth() + 1).padStart(2, "0");
  const DD = String(utcNow.getUTCDate()).padStart(2, "0");
  const HH = String(utcNow.getUTCHours()).padStart(2, "0");
  const min = String(utcNow.getUTCMinutes()).padStart(2, "0");
  const granularity = repeat === "hourly" ? `${HH}${min}` : `${HH}${min}`;
  return `${YYYY}${MM}${DD}T${granularity}|${reminderId}`;
}
async function handler() {
  const supabaseUrl = process.env.SUPABASE_URL;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const vapidPublicKey = process.env.VAPID_PUBLIC_KEY;
  const vapidPrivateKey = process.env.VAPID_PRIVATE_KEY;
  const vapidEmail = process.env.VAPID_EMAIL ?? "mailto:admin@example.com";
  if (!supabaseUrl || !serviceRoleKey || !vapidPublicKey || !vapidPrivateKey) {
    console.error("[push-reminders] Missing required env vars");
    return;
  }
  webpush.setVapidDetails(vapidEmail, vapidPublicKey, vapidPrivateKey);
  const headers = {
    apikey: serviceRoleKey,
    Authorization: `Bearer ${serviceRoleKey}`,
    "Content-Type": "application/json"
  };
  const base = `${supabaseUrl}/rest/v1`;
  const utcNow = /* @__PURE__ */ new Date();
  const stateRes = await fetch(`${base}/user_app_state?select=user_id,state_json`, { headers });
  if (!stateRes.ok) {
    console.error("[push-reminders] Failed to load app states:", await stateRes.text());
    return;
  }
  const states = await stateRes.json();
  const subRes = await fetch(
    `${base}/push_subscriptions?select=id,user_id,subscription,utc_offset_minutes`,
    { headers }
  );
  if (!subRes.ok) {
    console.error("[push-reminders] Failed to load subscriptions:", await subRes.text());
    return;
  }
  const allSubs = await subRes.json();
  let sent = 0;
  let skipped = 0;
  for (const row of states) {
    const reminders = row.state_json?.reminders ?? [];
    if (reminders.length === 0) continue;
    const userSubs = allSubs.filter((s) => s.user_id === row.user_id);
    if (userSubs.length === 0) continue;
    for (const sub of userSubs) {
      const offset = sub.utc_offset_minutes;
      for (const reminder of reminders) {
        if (!isDueNow(reminder, offset)) continue;
        const key = sentKey(reminder.id, utcNow, reminder.repeat);
        const dedupRes = await fetch(
          `${base}/push_sent_log?select=id&user_id=eq.${row.user_id}&dedup_key=eq.${encodeURIComponent(key)}&limit=1`,
          { headers }
        );
        const dedupRows = dedupRes.ok ? await dedupRes.json() : [];
        if (dedupRows.length > 0) {
          skipped++;
          continue;
        }
        const payload = JSON.stringify({
          title: reminder.title,
          body: `Reminder: ${reminder.title}`,
          icon: "/icons/icon-192x192.png",
          badge: "/icons/icon-192x192.png",
          tag: `reminder-${reminder.id}`
        });
        try {
          await webpush.sendNotification(
            sub.subscription,
            payload
          );
          await fetch(`${base}/push_sent_log`, {
            method: "POST",
            headers,
            body: JSON.stringify({
              user_id: row.user_id,
              dedup_key: key
            })
          });
          sent++;
        } catch (err) {
          if (err.statusCode === 410) {
            await fetch(`${base}/push_subscriptions?id=eq.${sub.id}`, {
              method: "DELETE",
              headers
            });
            console.log("[push-reminders] Removed stale subscription:", sub.id);
          } else {
            console.error("[push-reminders] sendNotification error:", err);
          }
        }
      }
    }
  }
  console.log(`[push-reminders] done \u2014 sent=${sent} skipped=${skipped}`);
}
var config = {
  schedule: "* * * * *"
  // every minute
};
export {
  config,
  handler as default
};
