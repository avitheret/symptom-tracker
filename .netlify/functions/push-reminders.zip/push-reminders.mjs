
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/push-reminders.mts
async function handler() {
  const supabaseUrl = process.env.SUPABASE_URL;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!supabaseUrl || !serviceRoleKey) {
    console.error("[push-reminders] Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY");
    return;
  }
  const url = `${supabaseUrl}/functions/v1/send-push-notifications`;
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${serviceRoleKey}`,
        "Content-Type": "application/json"
      },
      body: "{}"
    });
    if (res.ok) {
      const data = await res.json();
      console.log(`[push-reminders] sent=${data.sent} skipped=${data.skipped}`);
    } else {
      console.error(`[push-reminders] Edge Function returned ${res.status}:`, await res.text());
    }
  } catch (err) {
    console.error("[push-reminders] fetch error:", err);
  }
}
var config = {
  schedule: "* * * * *"
  // every minute
};
export {
  config,
  handler as default
};
