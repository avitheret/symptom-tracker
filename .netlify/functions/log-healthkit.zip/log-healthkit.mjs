
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/log-healthkit.mts
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type"
};
async function handler(req, _ctx) {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS });
  }
  if (req.method !== "POST") {
    return Response.json({ error: "Method not allowed" }, { status: 405, headers: CORS });
  }
  const supabaseUrl = process.env.SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!supabaseUrl || !serviceKey) {
    console.error("[log-healthkit] Missing env vars");
    return Response.json({ error: "Server misconfiguration" }, { status: 500, headers: CORS });
  }
  let body;
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "Invalid JSON body" }, { status: 400, headers: CORS });
  }
  const { token, date, metrics } = body;
  if (!token || typeof token !== "string" || token.length < 10) {
    return Response.json({ error: "Missing or invalid token" }, { status: 401, headers: CORS });
  }
  if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    return Response.json({ error: "Invalid date \u2014 expected YYYY-MM-DD" }, { status: 400, headers: CORS });
  }
  if (!Array.isArray(metrics) || metrics.length === 0) {
    return Response.json({ error: "No metrics provided" }, { status: 400, headers: CORS });
  }
  const base = `${supabaseUrl}/rest/v1`;
  const svcHeaders = {
    apikey: serviceKey,
    Authorization: `Bearer ${serviceKey}`,
    "Content-Type": "application/json"
  };
  const tokenRes = await fetch(
    `${base}/healthkit_tokens?token=eq.${encodeURIComponent(token)}&select=user_id&limit=1`,
    { headers: svcHeaders }
  );
  if (!tokenRes.ok) {
    console.error("[log-healthkit] token lookup failed:", await tokenRes.text());
    return Response.json({ error: "Database error" }, { status: 500, headers: CORS });
  }
  const tokenRows = await tokenRes.json();
  if (!Array.isArray(tokenRows) || tokenRows.length === 0) {
    return Response.json({ error: "Invalid token" }, { status: 401, headers: CORS });
  }
  const userId = tokenRows[0].user_id;
  const ALLOWED_TYPES = /* @__PURE__ */ new Set([
    "sleep_hours",
    "resting_hr",
    "steps",
    "hrv",
    "systolic_bp",
    "diastolic_bp"
  ]);
  const rows = metrics.filter(
    (m) => typeof m.type === "string" && ALLOWED_TYPES.has(m.type) && typeof m.value === "number" && isFinite(m.value)
  ).map((m) => ({
    user_id: userId,
    date,
    type: m.type,
    value: m.value,
    unit: m.unit ?? "",
    source: "ios_shortcuts"
  }));
  if (rows.length === 0) {
    return Response.json({ ok: true, inserted: 0 }, { status: 200, headers: CORS });
  }
  const upsertRes = await fetch(`${base}/health_metrics`, {
    method: "POST",
    headers: { ...svcHeaders, Prefer: "resolution=merge-duplicates" },
    body: JSON.stringify(rows)
  });
  if (!upsertRes.ok) {
    const err = await upsertRes.text();
    console.error("[log-healthkit] upsert failed:", err);
    return Response.json({ error: "Failed to store metrics" }, { status: 500, headers: CORS });
  }
  console.log(`[log-healthkit] stored ${rows.length} metric(s) for user ${userId.slice(0, 8)}\u2026 on ${date}`);
  return Response.json({ ok: true, inserted: rows.length }, { status: 200, headers: CORS });
}
export {
  handler as default
};
